	@extends('frontend.layouts.master')

	@section('content')
		<div class="container signup-body text-center">
			<strong>{{ __( 'messages.verification_link' ) }}</strong> 
		</div>
	@endsection