<div class="pull-right hidden-xs">
  	<b>{{ __( 'messages.version' ) }}</b> 2.4.0
</div>
<strong>
	{{ __( 'messages.copyright' ) }} &copy; {{ \Carbon\Carbon::now()->format('Y') }} 
	<a href="{{ url('/') }}" target="_tab">{{ config('app.name', 'Laravel') }}</a>. 
</strong> 
{{ __( 'messages.all_right_reserved' ) }}