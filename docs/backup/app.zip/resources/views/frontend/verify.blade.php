	@extends('frontend.layouts.master')

	@section('content')
		<div class="container signup-body">
			@include('frontend.elements.message')
		</div>
	@endsection