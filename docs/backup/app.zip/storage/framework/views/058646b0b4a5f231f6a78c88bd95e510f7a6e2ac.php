	

	<?php $__env->startSection('content'); ?>
		<?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('frontend.home_template.banner_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="container">
			<?php if( isset( $settings ) && count ( $settings ) > 0 ): ?>	
				<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if( $setting->type == 'ads' ): ?>
						<?php echo $__env->make('frontend.home_template.advertisement', [ 'advertisment' => $home_settings[$setting->type ], 'heading' => $setting->heading ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php elseif( $setting->type == 'tag' ): ?>
						<?php echo $__env->make('frontend.account.recommended_video', [ 'recommended_videos' => $home_settings[$setting->type] , 'heading' => $setting->heading ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php elseif( $setting->type == 'trending' ): ?>
						<?php echo $__env->make('frontend.home_template.trending_video', [ 'trending_videos' => $home_settings[$setting->type], 'heading' => $setting->heading ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php elseif( $setting->type == 'popular' ): ?>
						<?php echo $__env->make('frontend.home_template.popular_video', [ 'popular_videos' => $home_settings[$setting->type], 'heading' => $setting->heading ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php else: ?>
						<?php $__currentLoopData = $home_settings[$setting->type]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php echo $__env->make('frontend.home_template.playlist_video', [ 'playlist_videos' => $home ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>