<?php if( isset( $trending_videos ) && count( $trending_videos) > 0 ): ?>
    <section id="trending-videos">
        <h2 class="bd-tranding">
            <?php if( isset( $heading ) && !empty( $heading ) ): ?>
                <?php echo e($heading); ?>

            <?php else: ?>
                <?php echo e(__( 'messages.recommended_videos' )); ?>

            <?php endif; ?>
        </h2>  
        <div class="slider responsive">
            <?php $__currentLoopData = $trending_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(url('trending/'.$trending['slug'])); ?>" title="<?php echo e($trending['name']); ?>">
                        <img class="card-img-top" src="<?php echo e($trending['images']['thumbnail']['src']); ?>" alt="<?php echo e($trending['name']); ?>" title="<?php echo e($trending['name']); ?>" />
                    </a>
                    <div class="card-body">
                        <h6 class="card-title">
                            <a href="<?php echo e(url('trending/'.$trending['slug'])); ?>" title="<?php echo e($trending['name']); ?>">
                                <?php echo e($trending['name']); ?>

                            </a>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>