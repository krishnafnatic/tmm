<div class="container-fluid px-0">
    <div class="carousel-inner home-prime-video">
        <div class="container">
           <div class="card">
	            <div class="card-image">
	                <div class="embed-responsive embed-responsive-16by9">
						<iframe src="//players.brightcove.net/<?php echo e($banner['account_id']); ?>/iGAicgqoE9_default/index.html?videoId=<?php echo e($banner['video_id']); ?>" 
						allowfullscreen 
						webkitallowfullscreen 
						mozallowfullscreen></iframe>
					</div>
	            </div>
	            
	            <div class="card-content">       
	                <h1 class="card-title"><?php echo e($banner['name']); ?></h1>
	                <p><?php echo e($banner['description']); ?></p>
	            </div>
        	</div>
        </div>
    </div>
</div>