<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php if(isset($menu_item->id)): ?>
          <i class="fa fa-edit"></i>
          <?php echo e(__( 'messages.edit' )); ?>  
        <?php else: ?>
          <i class="fa fa-plus"></i>
          <?php echo e(__( 'messages.add' )); ?>

        <?php endif; ?>
          <?php echo e(__( 'messages.menu' )); ?>

        <small>Item</small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/menu/")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>
          <?php echo e(__( 'messages.back' )); ?>

        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.menu')); ?>">
            <?php echo e(__( 'messages.menu' )); ?>

          </a>
        </li>
        <li>
          <a href="<?php echo e(url("admin/menu/item/$id/listing")); ?>">
            <?php echo e(__( 'messages.menu_item' )); ?>

          </a>
        </li>
        <li class="active">
          <?php if(isset($menu_item->id)): ?>
            <?php echo e(__( 'messages.edit' )); ?>  
          <?php else: ?>
            <?php echo e(__( 'messages.add' )); ?>

          <?php endif; ?>
          <?php echo e(__( 'messages.menu_item' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-9 col-md-offset-1">
          <!-- general form elements -->
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box box-primary">
            <form class="form" role="form" method="POST" <?php if(isset($menu_item->id)): ?> action="<?php echo e(url("admin/menu/item/$id/$menu_item->id/edit")); ?>" <?php else: ?> action="<?php echo e(url("admin/menu/item/$id/create")); ?>" <?php endif; ?>>
              <?php echo e(csrf_field()); ?>


              <?php if( isset($menu_item->id)): ?>
                <input type="hidden" name="id" value="<?php echo e($menu_item->id); ?>" />
              <?php endif; ?>
              <input type="hidden" name="menu_id" value="<?php echo e($id); ?>" />
              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                  <label for="title"><?php echo e(__( 'messages.title' )); ?></label>
                  <input type="text" class="form-control" id="title" name="title" placeholder="<?php echo e(__( 'messages.enter_title' )); ?>" <?php if( isset($menu_item->id)): ?> value="<?php echo e($menu_item->title); ?>" <?php else: ?> value="<?php echo e(old('title')); ?>" <?php endif; ?> maxlength="50" required autocomplete="off" />
                  <?php if($errors->has('title')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('title')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('slug') ? ' has-error' : ''); ?>">
                  <label for="slug"><?php echo e(__( 'messages.slug' )); ?></label>
                  <input type="text" class="form-control" id="slug" name="slug" placeholder="<?php echo e(__( 'messages.enter_slug' )); ?>" <?php if( isset($menu_item->id)): ?> value="<?php echo e($menu_item->slug); ?>" <?php else: ?> value="<?php echo e(old('slug')); ?>" <?php endif; ?> maxlength="50" required autocomplete="off" />
                  <?php if($errors->has('slug')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('slug')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('parent_id') ? ' has-error' : ''); ?>">
                  <label><?php echo e(__( 'messages.parent_menu' )); ?></label>
                  <select class="form-control select2" style="width: 100%;" name="parent_id">
                    <?php if(isset($menu_item->id)): ?>
                      <option value="0" <?php if($menu_item->parent_id == 0): ?> selected="selected" <?php endif; ?>>
                        <?php echo e(__( 'messages.root_menu' )); ?>

                      </option>
                    <?php else: ?>
                      <option value="0"><?php echo e(__( 'messages.root_menu' )); ?></option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(isset($menu_item->id)): ?>
                        <option value="<?php echo e($menu->id); ?>" <?php if($menu_item->parent_id == $menu->id): ?> selected="selected" <?php endif; ?>>
                          <?php echo e($menu->title); ?>

                        </option>
                      <?php else: ?>
                        <option value="<?php echo e($menu->id); ?>">
                          <?php echo e($menu->title); ?>

                        </option>
                      <?php endif; ?>;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('parent_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('parent_id')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('target') ? ' has-error' : ''); ?>">
                  <label for="target"><?php echo e(__( 'messages.target' )); ?></label>
                  <input type="text" class="form-control" id="target" name="target" placeholder="<?php echo e(__( 'messages.enter_target' )); ?>" <?php if(isset($menu_item->id)): ?> value="<?php echo e($menu_item->target); ?>" <?php else: ?> value="<?php echo e(old('target')); ?>" <?php endif; ?> maxlength="20" autocomplete="off">
                  <small>for eg: "_blank", "_self", "_parent", "_tab", "_top"</small>
                  <?php if($errors->has('target')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('target')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('icon_class') ? ' has-error' : ''); ?>">
                  <label for="icon_class"><?php echo e(__( 'messages.icon_class' )); ?></label>
                  <input type="text" class="form-control" id="icon_class" name="icon_class" placeholder="<?php echo e(__( 'messages.enter_icon' )); ?>" <?php if(isset($menu_item->id)): ?> value="<?php echo e($menu_item->icon_class); ?>" <?php else: ?> value="<?php echo e(old('icon_class')); ?>" <?php endif; ?> maxlength="20" autocomplete="off" />
                </div>

                <div class="form-group<?php echo e($errors->has('order') ? ' has-error' : ''); ?>">
                  <label for="order"><?php echo e(__( 'messages.order' )); ?></label>
                  <input type="text" class="form-control" id="order" name="order" placeholder="<?php echo e(__( 'messages.enter_order' )); ?>" <?php if(isset($menu_item->id)): ?> value="<?php echo e($menu_item->order); ?>" <?php else: ?> value="<?php echo e(old('order')); ?>" <?php endif; ?> maxlength="4" required autocomplete="off" />
                  <?php if($errors->has('order')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('order')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(__( 'messages.submit' )); ?></button>
              </div>
            </form>
          </div> 
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.form_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>