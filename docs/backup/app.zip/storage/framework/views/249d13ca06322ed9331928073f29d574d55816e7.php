<?php if( isset( $wishlist ) && count( $wishlist) > 0 ): ?>
    <section id="popular-videos">
     	<h2 class="bd-magenta no-bd-lft"><?php echo e(__( 'messages.my_list' )); ?></h2>  
        <div class="slider responsive">
            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(url('video/'.$wish['slug'])); ?>" class="card-title">
                        <img class="card-img-top" src="<?php echo e($wish['images']['thumbnail']['src']); ?>" alt="<?php echo e($wish['name']); ?>" title="<?php echo e($wish['name']); ?>" />
                    </a>
                    <div class="card-body">
                        <h6 class="card-title">
                            <a href="<?php echo e(url('video/'.$wish['slug'])); ?>" class="card-title">
                                <?php echo e($wish['name']); ?>

                            </a>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>