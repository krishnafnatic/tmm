<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php if(isset($id)): ?>
          <i class="fa fa-edit"></i>
          <?php echo e(__( 'messages.edit' )); ?>

        <?php else: ?>
          <i class="fa fa-plus"></i>
          <?php echo e(__( 'messages.add' )); ?>

        <?php endif; ?>
        <small><?php echo e(__( 'messages.language' )); ?></small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/language")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>
          <?php echo e(__( 'messages.back' )); ?>

        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.language')); ?>">
            <?php echo e(__( 'messages.language' )); ?>

          </a>
        </li>
        <li class="active">
          <?php if(isset($id)): ?>
            <?php echo e(__( 'messages.edit' )); ?>

          <?php else: ?>
            <?php echo e(__( 'messages.add' )); ?>

          <?php endif; ?>
          <?php echo e(__( 'messages.language' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-9 col-md-offset-1">
          <!-- general form elements -->
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box box-primary">
            <form class="form" role="form" method="POST" <?php if(isset($id)): ?> action="<?php echo e(url("admin/language/$id/edit")); ?>" <?php else: ?> action="<?php echo e(route('admin.language.create.submit')); ?>" <?php endif; ?> />
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                  <label for="name"><?php echo e(__( 'messages.name' )); ?></label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(__( 'messages.enter_name' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($lang->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>" <?php endif; ?> maxlength="25" required autofocus autocomplete="off" />
                  <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                  <label for="code"><?php echo e(__( 'messages.code' )); ?></label>
                  <input type="text" class="form-control" id="code" name="code" placeholder="<?php echo e(__( 'messages.enter_code' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($lang->code); ?>" <?php else: ?> value="<?php echo e(old('code')); ?>" <?php endif; ?> maxlength="5" required autocomplete="off"  />
                  <?php if($errors->has('code')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('code')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group<?php echo e($errors->has('locale') ? ' has-error' : ''); ?>">
                  <label for="locale"><?php echo e(__( 'messages.locale' )); ?></label>
                  <input type="text" class="form-control" id="locale" name="locale" placeholder="<?php echo e(__( 'messages.enter_locale' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($lang->locale); ?>" <?php else: ?> value="<?php echo e(old('locale')); ?>" <?php endif; ?> maxlength="5" required autocomplete="off" />
                  <?php if($errors->has('locale')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('locale')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                  <label for="image"><?php echo e(__( 'messages.image' )); ?></label>
                  <input type="text" class="form-control" id="image" name="image" placeholder="<?php echo e(__( 'messages.enter_image' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($lang->image); ?>" <?php else: ?> value="<?php echo e(old('image')); ?>" <?php endif; ?> maxlength="20"  autocomplete="off" />
                  <?php if($errors->has('image')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('image')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group<?php echo e($errors->has('order') ? ' has-error' : ''); ?>">
                  <label for="order"><?php echo e(__( 'messages.order' )); ?></label>
                  <input type="text" class="form-control" id="order" name="order" placeholder="<?php echo e(__( 'messages.enter_order' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($lang->order); ?>" <?php else: ?> value="<?php echo e(old('order')); ?>" <?php endif; ?> maxlength="4" required autocomplete="off" />
                  <?php if($errors->has('order')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('order')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                  <label for="order">Status</label>
                  <select name="status" id="status" class="form-control">
                    <option value="1" <?php if(isset($lang->status) && $lang->status == 1): ?> selected="selected" <?php endif; ?>><?php echo e(__( 'messages.active' )); ?></option>
                    <option value="0" <?php if(isset($lang->status) && $lang->status == 0): ?> selected="selected" <?php endif; ?>><?php echo e(__( 'messages.inactive' )); ?></option>
                  </select>
                  <?php if($errors->has('status')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('status')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(__( 'messages.submit' )); ?></button>
              </div>
            </form>
          </div> 
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.form_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>