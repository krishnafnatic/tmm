	

	<?php $__env->startSection('content'); ?>
		<div class="container">
			<?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="row search-list-header">
				<div class="col-sm-10">  
					<h1>
						<?php echo e(__( 'messages.tag' )); ?>:
						"<?php echo e($tag); ?>"
					</h1> 
				</div> 
			</div>

			<div class="video-listing  pl-0">
				<?php if( $vidoes > 0 ): ?>
					<?php $__currentLoopData = $vidoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="row video-list-card">
							<div class="col-sm-3 pl-0">
								<a href="<?php echo e(url( 'video/'.$video['slug'] )); ?>">
									<img src="<?php echo e($video['images']['thumbnail']['src']); ?>" title="<?php echo e($video['name']); ?>" slug="<?php echo e($video['name']); ?>" />
								</a>
							</div>
							<div class="col-sm-8 video_id_<?php echo e($video['video_id']); ?>">
								<h3>
									<a href="<?php echo e(url( 'video/'.$video['slug'] )); ?>">

										<?php echo e($video['name']); ?>

									</a>
								</h3> 

								<p> <?php echo e($video['description']); ?> </p>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div> 
		</div>  
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>