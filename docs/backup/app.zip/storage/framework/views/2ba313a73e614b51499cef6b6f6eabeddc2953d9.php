<?php $__env->startSection('content'); ?>
  <div class="login-box">
    <div class="login-logo">
      <a href="<?php echo e(url('/')); ?>" target="_tab">
        <?php echo e(__( 'messages.administrator' )); ?>

        <?php echo e(config('app.name', 'Laravel')); ?>

      </a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
      <p class="login-box-msg"><?php echo e(__( 'messages.sign_in_as' )); ?></p>

      <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
      <?php if(session('warning')): ?>
          <div class="alert alert-warning">
              <?php echo e(session('warning')); ?>

          </div>
      <?php endif; ?>

      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('admin.login.submit')); ?>" autocomplete="off">
        <?php echo e(csrf_field()); ?>

        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> has-feedback">
          <input type="email" class="form-control" placeholder="<?php echo e(__( 'messages.email' )); ?>" id="email" name="email" autocomplete="false" required autofocus />
          <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
          <?php endif; ?>
        </div>
        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> has-feedback">
          <input type="password" class="form-control" placeholder="<?php echo e(__( 'messages.password' )); ?>" name="password" required autocomplete="off" />
          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
           <?php if($errors->has('password')): ?>
              <span class="help-block">
                  <strong><?php echo e($errors->first('password')); ?></strong>
              </span>
          <?php endif; ?>
        </div>
        <div class="row">
          <!-- /.col -->
          <div class="col-xs-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat"><?php echo e(__( 'messages.sign_in' )); ?></button>
          </div>
          <!-- /.col -->
        </div>
      </form>
    </div>
    <!-- /.login-box-body -->
  </div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.login_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>