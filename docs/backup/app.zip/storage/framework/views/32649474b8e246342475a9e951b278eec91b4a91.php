<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          <i class="fa fa-lock"></i>
          <?php echo e(__( 'messages.change' )); ?>

        <small><?php echo e(__( 'messages.password' )); ?></small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/dashboard")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>
          <?php echo e(__( 'messages.back' )); ?>

        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li class="active">
          <?php echo e(__( 'messages.change_password' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-9 col-md-offset-1">
          <!-- general form elements -->
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box box-primary">
            <form class="form" role="form" method="POST" action="<?php echo e(route('admin.changepassword.submit')); ?>">
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('current-password') ? ' was-validated' : ''); ?>">
                  <label class="col-12 pl-0" for="current-password">
                      <?php echo e(__( 'messages.current_password' )); ?>

                  </label>
                  <input id="current-password" type="password" name="current-password" class="col-12 form-control" value="<?php echo e(old( 'current-password' )); ?>" autocomplete="off" required autofocus />
                  <?php if($errors->has('current-password')): ?>
                      <span class="text-danger">
                          <strong><?php echo e($errors->first('current-password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>  

                <div class="form-group<?php echo e($errors->has('new-password') ? ' was-validated' : ''); ?>">
                  <label class="col-12 pl-0" for="new-password">
                      <?php echo e(__( 'messages.new_password' )); ?>

                  </label>
                  <input id="new-password" type="password" name="new-password" class="col-12 form-control is-invalid" value="<?php echo e(old( 'new-password' )); ?>" autocomplete="off" required />
                  <?php if($errors->has('new-password')): ?>
                      <span class="text-danger">
                          <strong><?php echo e($errors->first('new-password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div> 

                <div class="form-group">
                    <label class="col-12 pl-0" for="new-password-confirm">
                        <?php echo e(__( 'messages.confirm_new_password' )); ?>

                    </label>
                    <input id="new-password-confirm" type="password" name="new-password_confirmation" class="col-12 form-control" value="<?php echo e(old( 'new-password_confirmation' )); ?>" autocomplete="off" required />
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(__( 'messages.submit' )); ?></button>
              </div>
            </form>
          </div> 
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.form_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>