 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="user-account-holder card">
            <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">  
                <div class="col-sm-3 tmm-account-tab">
                    <div class="nav flex-column nav-pills account-tabs" id="v-pills-tab" role="account" aria-orientation="vertical">
                        <a class="nav-link" href="<?php echo e(route( 'profile' )); ?>" role="profile">
                            <?php echo e(__( 'messages.profile' )); ?>

                        </a>
                        <a class="nav-link active" href="<?php echo e(route( 'change-password' )); ?>" role="change-password">
                            <?php echo e(__( 'messages.password' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'user-notification' )); ?>" role="notification">
                            <?php echo e(__( 'messages.notification' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'profile-deactivate' )); ?>" role="deactivate_account">
                            <?php echo e(__( 'messages.deactivate_account' )); ?>

                        </a>
                    </div>
                </div>  
                
                <div class="col-sm-9">
                    <div class="tab-content" id="v-pills-tabContent">
                         <div class="tab-pane fade show active" id="change-password" role="change-password">
                            <form class="form-horizontal" role="change-password" method="POST" action="<?php echo e(route('change-password')); ?>" autocomplete="on">
                                <?php echo e(csrf_field()); ?>

                                <h3> <?php echo e(__( 'messages.manage_password' )); ?> </h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group<?php echo e($errors->has('current-password') ? '' : ''); ?>">
                                            <label class="col-sm-12 pl-0" for="current-password">
                                                <?php echo e(__( 'messages.current_password' )); ?>

                                            </label>
                                            <input id="current-password" type="password" name="current-password" class="col-sm-12 form-control <?php if($errors->has('current-password')): ?> is-invalid <?php endif; ?>" autocomplete="off" required autofocus />
                                            <?php if($errors->has('current-password')): ?>
                                                <span class="text-danger">
                                                   <?php echo e($errors->first('current-password')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div> 

                                        <div class="form-group<?php echo e($errors->has('new-password') ? '' : ''); ?>">
                                            <label class="col-sm-12 pl-0" for="new-password">
                                                <?php echo e(__( 'messages.new_password' )); ?>

                                            </label>
                                            <input id="new-password" type="password" name="new-password" class="col-sm-12 form-control <?php if($errors->has('new-password')): ?> is-invalid <?php endif; ?>" autocomplete="off" required />
                                            <?php if($errors->has('new-password')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('new-password')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div> 

                                        <div class="form-group">
                                            <label class="col-sm-12 pl-0" for="new-password-confirm">
                                                <?php echo e(__( 'messages.confirm_new_password' )); ?>

                                            </label>
                                            <input id="new-password-confirm" type="password" name="new-password_confirmation" class="col-sm-12 form-control" autocomplete="off" required />
                                        </div>

                                        <div class="user-social-inputs-action">
                                            <button type="button" class="btn btn-secondary" onclick="event.preventDefault();window.history.back();">
                                                <?php echo e(__( 'messages.cancel' )); ?>

                                            </button>&nbsp;&nbsp;
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__( 'messages.update' )); ?>

                                            </button>
                                        </div> 
                                    </div>
                                    <div class="col-sm-6 text-right">
                                        <img src="<?php echo e(asset( 'frontend/images/lock.png' )); ?>" class="lock" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<style type="text/css">
    .was-validated .is-invalid {
            border-color: #dc3545 !important;
    }
</style>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>