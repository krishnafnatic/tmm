	

	<?php $__env->startSection('content'); ?>
		<div class="container signup-body text-center">
			<strong><?php echo e(__( 'messages.verification_link' )); ?></strong> 
		</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>