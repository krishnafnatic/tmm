<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          <i class="fa fa-gear"></i>
          <?php echo e(__( 'messages.change' )); ?>

        <small><?php echo e(__( 'messages.setting' )); ?></small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/dashboard")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>
          <?php echo e(__( 'messages.back' )); ?>

        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li class="active">
          <?php echo e(__( 'messages.setting' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="container" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="alert alert-danger print-error-msg" style="display:none">
            <ul></ul>
          </div>


          <div class="alert alert-success print-success-msg" style="display:none">
            <ul></ul>
          </div>

          <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
          <div class="box box-primary">
            <form name="add_name" id="add_name" enctype="multipart/form-data" action="<?php echo e(route('admin.setting.store.submit')); ?>" method="POST" role="setting"> 
              <?php echo e(csrf_field()); ?>

              <!-- /.box-body --> 
              <div class="table-responsive">  
                <table class="table table-bordered" id="dynamic_field">
                    <thead>
                      <tr>
                          <th>Type</th>
                          <th>Heading</th>
                          <th>Order</th>
                          <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if( isset( $setting ) && count( $setting ) > 0 ): ?>
                        <?php for( $i=0; $i < count( $setting ); $i++ ): ?>
                          <tr id="row_<?php echo e($i); ?>">
                            <input type="hidden" name="setting[<?php echo e($i); ?>][id]" value="<?php echo e($setting[$i]['id']); ?>" />
                            <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'ads'): ?> 
                              <input type="hidden" name="setting[<?php echo e($i); ?>][type_id]" value="<?php echo e($setting[$i]['type_id']); ?>" />
                            <?php endif; ?>
                            <td style="width: 55px; ">
                              <select name="setting[<?php echo e($i); ?>][type]" id="type_<?php echo e($i); ?>" class="form-control select_type_<?php echo e($i); ?>" onchange="getval(this, <?php echo e($i); ?>);">
                                <option value="0"> Select</option> s
                                <option value="ads" <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'ads'): ?> selected="selected" <?php endif; ?>> Advertisement</option>
                                <option value="tag" <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'tag'): ?> selected="selected" <?php endif; ?>>Recommend</option>
                                <option value="popular" <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'popular'): ?> selected="selected" <?php endif; ?>>Popular</option>
                                <option value="trending" <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'trending'): ?> selected="selected" <?php endif; ?>>Most Viewed</option>
                                <?php if( isset( $playlist ) && count( $playlist ) > 0 ): ?>
                                  <?php $__currentLoopData = $playlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($listing['slug']); ?> " <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == $listing['slug'] ): ?> selected="selected" <?php endif; ?>>
                                      <?php echo e($listing['name']); ?> 
                                  </option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                              </select>
                              <span class="help-block" id="type_error_<?php echo e($i); ?>"></span>
                            </td>
                            <td style="width: 30px; "> 
                                <input type="text" name="setting[<?php echo e($i); ?>][heading]" id="heading_<?php echo e($i); ?>" class="form-control" value="<?php echo e($setting[$i]['heading']); ?>" placeholder="Add heading" autofocus required /> 
                            </td>
                            <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == 'ads'): ?> 
                            <td style="width: 100px; ">  
                                <img src="<?php echo e(asset( $setting[$i]['image'])); ?>" width="40" height="40" />
                                <input type="file" name="setting[<?php echo e($i); ?>][image]" id="image_<?php echo e($i); ?>" class="form-control" />
                               
                                <input type="text" name="setting[<?php echo e($i); ?>][order]" id="order_<?php echo e($i); ?>" placeholder="Add Order" class="form-control" value="<?php echo e($setting[$i]['order']); ?>" autocomplete="off" required />
                               

                              <!-- <div class="col-xs-3"> 
                                <input type="text" name="setting[<?php echo e($i); ?>][width]" id="width_<?php echo e($i); ?>" placeholder="Add width of image" class="form-control" value="<?php echo e($setting[$i]['width']); ?>" autocomplete="off"required />
                              </div>
                                
                              <div class="col-xs-3"> 
                                <input type="text" name="setting[<?php echo e($i); ?>][height]" id="height_<?php echo e($i); ?>" placeholder="Add height of image" class="form-control" value="<?php echo e($setting[$i]['height']); ?>" autocomplete="off" required /> 
                              </div> -->
                            </td>
                            <?php else: ?> 
                            <td style="width: 100px; "> 
                                <input name="setting[<?php echo e($i); ?>][order]" type="text" placeholder="Add Order" class="form-control" style="" value="<?php echo e($setting[$i]['order']); ?>" required />
                                <span class="help-block" id="order_error_<?php echo e($i); ?>"></span> 
                            </td> 
                            <?php endif; ?>
                            <td style="width: 75px; ">
                              <select name="setting[<?php echo e($i); ?>][status]" id="status_<?php echo e($i); ?>" class="form-control select_status_<?php echo e($i); ?>">
                                <option value="active" <?php if(isset( $setting[$i]['status'] ) && $setting[$i]['status'] == 'active'): ?> selected="selected" <?php endif; ?>>Active</option>
                                <option value="inactive" <?php if(isset( $setting[$i]['status'] ) && $setting[$i]['status'] == 'inactive'): ?> selected="selected" <?php endif; ?>>In Active</option>
                              </select>
                            </td> 
                            <!-- <td class="text-center">
                              <button type="button" class="btn btn-danger remove btn_remove" id="<?php echo e($i); ?>">
                                <i class="glyphicon glyphicon-remove-sign"></i>
                              </button>
                            </td> -->
                          </tr>
                        <?php endfor; ?>
                      <?php else: ?> 
                        <tr id="row_0">  
                          <td>
                            <select name="setting[0][type]" id="type_0" class="form-control select_0" onchange="getval(this, 0);">
                              <option value="0"> Select</option>
                              <option value="ads">Advertisement</option>
                              <option value="tag">Recommend</option>
                              <option value="popular">Popular</option>
                              <option value="most">Most Viewed</option>
                            </select>
                          </td>
                          <td class="text-center" id="order_0">
                            <input type="text" name="setting[0][order]" placeholder="Add Order" class="form-control" autocomplete="off" autofocus required />
                          </td>
                          <td class="text-center">
                            <button type="button" class="btn btn-danger remove">
                              <i class="glyphicon glyphicon-remove-sign"></i>
                            </button>
                          </td>
                        </tr> 
                      <?php endif; ?>
                    <script type="text/javascript">
                      var count = <?php echo e(count( $setting )); ?>;
                    </script>
                    </tbody>
                </table> 
                <div class=" text-right">
                  <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />  
                  <button type="button" name="add" id="add" class="btn btn-success">Add More</button>
                </div>
                  
              </div>
            </form>
          </div> 
        </div>
      </div>
    </section>
  </div>
  <optgroup label="Playlist" id="playlist">
    <?php if( isset( $playlist ) && count( $playlist ) > 0 ): ?>
      <?php $__currentLoopData = $playlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($listing['slug']); ?> " <?php if(isset( $setting[$i]['type'] ) && $setting[$i]['type'] == $listing['slug'] ): ?> selected="selected" <?php endif; ?>>
          <?php echo e($listing['name']); ?> 
      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </optgroup>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.setting_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>