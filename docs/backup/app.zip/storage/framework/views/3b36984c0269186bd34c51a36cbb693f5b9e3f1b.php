<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-th"></i>
        <?php echo e(__( 'messages.menu_item' )); ?>

        <small><?php echo e(__( 'messages.listing' )); ?></small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/menu/item/$id/create")); ?>'"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp;<?php echo e(__( 'messages.add_new_menu_item' )); ?></button>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/menu/")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>  
          <?php echo e(__( 'messages.back' )); ?> 
        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?> 
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.menu')); ?>">
            <?php echo e(__( 'messages.menu' )); ?>

          </a>
        </li>
        <li class="active">
          <?php echo e(__( 'messages.builder_listing' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-9 col-md-offset-1">
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box">
           <!--  <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div> -->
            <!-- /.box-header -->
            <div class="box-body">
              <table id="listing2" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.title' )); ?> 
                    </th> 
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.slug' )); ?>

                    </th>
                    <th class="th-sm text-center">
                      <?php echo e(__( 'messages.action' )); ?>

                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $menu_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($menu->title); ?> </td>
                    <td class="th-sm text-left"><?php echo e($menu->slug); ?></td>
                    <td class="text-center">  
                        <button type="button" class="btn bg-blue text-right edit" onclick="window.location='<?php echo e(url("admin/menu/item/$id/$menu->id/edit")); ?>'">
                          <i class="fa fa-edit float-left" aria-hidden="true"></i>
                          <?php echo e(__( 'messages.edit' )); ?>

                        </button> 
                        <button type="button" class="btn bg-red text-right delete" onclick="return menuDelete( '<?php echo e($menu->title); ?>', '<?php echo e(url("admin/menu/item/$id/$menu->id/delete")); ?>');">
                          <i class="fa fa-trash float-left" aria-hidden="true"></i>
                          <?php echo e(__( 'messages.delete' )); ?>

                        </button>

                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.title' )); ?>

                    </th>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.slug' )); ?>

                    </th>
                    <th class="th-sm text-center">
                      <?php echo e(__( 'messages.action' )); ?>

                    </th>
                  </tr>
                </tfoot>
              </table> 
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <style type="text/css">
     .sorting_asc, .sorting_desc {
      float: left;
      width: 80px !important;
    }
  </style>
  <script type="text/javascript">
      function menuDelete(  name, url ) {

        var txt;
         var confirmTxt = "<?php echo e(__( 'messages.confirm' )); ?> <?php echo e(__( 'messages.menu_item' )); ?>";
        var r = confirm(confirmTxt+" - " + name);
        if (r == true) {
            window.location=url
        }
        return false;
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.listing_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>