<?php if( isset( $advertisment ) && !empty( $advertisment ) ): ?>
	<div class="tmm-image-ad" id="home-ad-1">
	 	<a href="https://www.paisabazaar.com/" target="_tab">
	 		<img src="<?php echo e(asset( $advertisment['image']  )); ?>" width="<?php echo e($advertisment['width']); ?>" height="<?php echo e($advertisment['height']); ?>"  class="img-fluid" />
	 	</a>
	</div>
<?php endif; ?>