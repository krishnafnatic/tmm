<header>
  <nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>" title="<?php echo e(config('app.name', 'TheMoneyMile')); ?>"> 
      <img src="<?php echo e(asset( 'frontend/images/the_money_mile_logo.png' )); ?>" width="220" height="30" title="<?php echo e(config('app.name', 'TheMoneyMile')); ?>" alt="<?php echo e(config('app.name', 'TheMoneyMile')); ?>" />
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <form class="form-inline my-2 my-lg-0 ml-auto" action="<?php echo e(route( 'search' )); ?>" method="post" role="search">
        <?php echo e(csrf_field()); ?>

        <div class="input-group">
          <input class="form-control py-2 border-right-0 border" type="text" placeholder="<?php echo e(__( 'messages.search' )); ?>" id="search" name="q" />
          <span class="input-group-append">
            <button class="btn btn-outline-secondary border-left-0 border" type="submit">
              <i class="fa fa-search"></i>
            </button>
          </span>
        </div>
      </form>
      <ul class="navbar-nav ml-auto">
        <?php if( isset( $menu_header) && count( $menu_header ) > 0 ): ?>
          <?php $__currentLoopData = $menu_header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($header->child_menu_items) == 0 ): ?>
              <li class="nav-item <?php echo e(Request::is( $header->slug ) ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url( $header->slug )); ?>">
                  <?php echo e($header->title); ?>

                  <span class="sr-only">(current)</span>
                </a>
              </li>
            <?php else: ?> 
              <li class="nav-item dropdown <?php echo e(Request::is('speaker*') ? 'active' : ''); ?>">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e($header->title); ?>

                </a>
                <div class="dropdown-menu master-speaker" aria-labelledby="navbarDropdown">
                  <?php $__currentLoopData = $header->child_menu_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href="<?php echo e(url( $child->slug )); ?>"><?php echo e($child->title); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('login')); ?>">
              <?php echo e(__( 'messages.log_in' )); ?>

            </a>
          </li>
        <?php else: ?>
          <li class="nav-item dropdown dropleft">
            <a class="nav-link dropdown-toggle user-login-initials" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo e(substr( Auth::user()->name, 0, 1)); ?>

            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <?php if( isset( $menu_profile ) && count( $menu_profile ) > 0 ): ?>
                <?php $__currentLoopData = $menu_profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(url( $profile->slug )); ?>" target="<?php echo e($profile->target); ?>" class="dropdown-item <?php echo e($profile->icon_class); ?>">
                      <?php echo e($profile->title); ?>

                  </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <div class="dropdown-divider"></div> 
              <a href="#" class="btn btn-default btn-flat"
                        onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
                <?php echo e(__( 'messages.logout' )); ?>

              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo e(csrf_field()); ?>

              </form>
            </div>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </nav>  
</header>