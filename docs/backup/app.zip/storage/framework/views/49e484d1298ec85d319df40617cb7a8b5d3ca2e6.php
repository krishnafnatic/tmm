<?php if(isset($success) || Session::has('success') ): ?>
	<div class="alert alert-success alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		Success! <?php echo e(isset($success) ? $info : Session::get('success')); ?>

	</div>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('status')): ?>
<div class="alert alert-success alert-dismissable">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<?php echo e($message); ?>

</div>
<?php endif; ?>