<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user"></i>
        <?php echo e(__( 'messages.user' )); ?>

        <small><?php echo e(__( 'messages.listing' )); ?></small> 
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?> 
          </a>
        </li>
        <li class="active">
          <?php echo e(__( 'messages.listing_user' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-9 col-md-offset-1">
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box">
            <!-- <div class="box-header">
              <h3 class="box-title">Data Table With Full Features</h3>
            </div> -->
            <!-- /.box-header -->
            <div class="box-body">
              <table id="listing1" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.name' )); ?> 
                    </th>

                    <th class="text-left">
                      <?php echo e(__( 'messages.email' )); ?> 
                    </th>
                    <th class="text-left">
                      <?php echo e(__( 'messages.mobile' )); ?> 
                    </th>
                    <th class="text-right">
                      <?php echo e(__( 'messages.action' )); ?>

                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-left"><?php echo e($user->name); ?> </td>
                    <td class="text-left"><?php echo e($user->email); ?> </td>
                    <td class="text-left">
                      <?php if($user->mobile): ?>
                        <?php echo e($user->mobile); ?>

                      <?php else: ?>
                        -
                      <?php endif; ?>
                    </td>
                    <!-- <td><?php echo e(App\Models\Role::where( 'id', $user->role_id )->first()->name); ?> </td> -->
                    <td class="text-right">
                        <button type="button" class="btn bg-blue text-right view" onclick="window.location='<?php echo e(url("admin/user/$user->id/view")); ?>'">
                          <i class="fa fa-street-view float-left" aria-hidden="true"></i>
                          <?php echo e(__( 'messages.view' )); ?>

                        </button> 

                        <!-- <button type="button" class="btn bg-red text-right delete" onclick="return userDelete( '<?php echo e($user->name); ?>', '<?php echo e(url("admin/user/$user->id/delete")); ?>');">
                          <i class="fa fa-trash float-left" aria-hidden="true"></i>
                          <?php echo e(__( 'messages.delete' )); ?>

                        </button> -->

                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                  <tr>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.name' )); ?>

                    </th>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.email' )); ?> 
                    </th>
                    <th class="th-sm text-left">
                      <?php echo e(__( 'messages.mobile' )); ?> 
                    </th>
                    <th class="th-sm text-right">
                      <?php echo e(__( 'messages.action' )); ?>

                    </th>
                  </tr>
                </tfoot>
              </table> 
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <style type="text/css">
     .sorting_asc, .sorting_desc {
      float: left;
      width: 80px !important;
    }
  </style>
  <script type="text/javascript">
      function userDelete(  name, url ) {

        var txt;
        var confirmTxt = "<?php echo e(__( 'messages.confirm' )); ?> <?php echo e(__( 'messages.user' )); ?>";
        var r = confirm(confirmTxt+" - " + name);
        if (r == true) {
            window.location=url
        }
        return false;
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.listing_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>