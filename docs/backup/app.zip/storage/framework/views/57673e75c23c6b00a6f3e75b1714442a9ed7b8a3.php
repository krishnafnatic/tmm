<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <!-- viewport -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Title -->
  <?php if( !empty( $meta['meta_title'] ) ): ?>
    <title><?php echo e($meta['meta_title']); ?> | <?php echo e(config('app.name', 'TheMoneyMile')); ?></title>
  <?php else: ?>
    <title><?php echo e(config('app.name', 'TheMoneyMile')); ?> | <?php echo e(config('app.message', 'TheMoneyMile')); ?></title>
  <?php endif; ?>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset( 'frontend/css/style.css' )); ?>" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto" /> 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous" />

  <?php if( !empty( $meta['meta_title'] ) ): ?>
    <meta name="author" content="<?php echo e($meta['meta_title']); ?>">
  <?php endif; ?>

  <?php if( !empty( $meta['meta_description'] ) ): ?>
    <meta name="description" content="<?php echo e($meta['meta_description']); ?>">
  <?php endif; ?>

  <?php if( !empty( $meta['meta_keyword'] ) ): ?>
    <meta name="keywords" content="<?php echo e($meta['meta_keyword']); ?>">
  <?php endif; ?>
</head>