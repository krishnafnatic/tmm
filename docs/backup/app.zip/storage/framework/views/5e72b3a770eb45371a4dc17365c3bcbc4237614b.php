<section id="popular-videos">
 	<h2 class="bd-magenta">Your List</h2>  
    <div class="slider responsive">
       	<div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>

        <div class="card">
            <img class="card-img-top" src="<?php echo e(asset( 'frontend/images/thumb.png' )); ?>" alt="Card image cap">
            <div class="card-body">
              <h6 class="card-title">Disruption is Pervasive | Demystifying Angel Investing</h6>
            </div>
        </div>
        
    </div>
</section>