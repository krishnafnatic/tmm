    

    <?php $__env->startSection('content'); ?>
        <div class="container signup-body">
            <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row justify-content-md-center">
                <div class="col-sm">
                    <div class="col-sm social-btn">
                        <a href="#" class="btn btn-primary col fb-login" onclick=" socialURL( '<?php echo e(route('auth.facebook')); ?>' )">
                            <i class="fab fa-facebook-square fa-2x"></i>
                            <div><?php echo e(__( 'messages.login_with_fb' )); ?></div>
                        </a>
                        <a href="#" class="btn btn-primary col gmail-login" onclick=" socialURL( '<?php echo e(route('auth.google')); ?> ' )">
                            <i class="fab fa-google fa-2x"></i>
                            <div><?php echo e(__( 'messages.login_with_gg' )); ?></div>
                        </a>
                        <a href="#" class="btn btn-primary col linkedin-login" onclick=" socialURL( '<?php echo e(route('auth.linkedin')); ?>' )">
                            <i class="fab fa-linkedin fa-2x"></i>
                            <div><?php echo e(__( 'messages.login_with_li' )); ?></div>
                        </a>
                    </div>
                </div>
                <div class="col-sm hidden-sm hidden-md">
                    <div class="vl">
                        <span class="or"> <?php echo e(__( 'messages.or' )); ?> </span>
                    </div>
                </div>
            
                <div class="col-sm signup-box">
                    <h3><?php echo e(__( 'messages.sign_up' )); ?></h3>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>" autocomplete="off">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group <?php echo e($errors->has('name') ? 'was-validated' : ''); ?>">
                            <label><?php echo e(__( 'messages.name' )); ?></label>
                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="off" />

                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback">
                                    <?php echo e($errors->first('name')); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('email') ? '' : ''); ?>">
                            <label><?php echo e(__( 'messages.email' )); ?></label>
                            <input id="email" type="email" class="form-control <?php if($errors->has('email')): ?> is-invalid  <?php endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="off" />

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" style="display: block !important;">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('password') ? '' : ''); ?>">
                            <label><?php echo e(__( 'messages.password' )); ?></label>
                            <input id="password" type="password" class="form-control <?php if($errors->has('password')): ?> is-invalid  <?php endif; ?>" name="password" autocomplete="new-password" required  />
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                            <?php endif; ?>
                            <p id="passwordHelpBlock" class="form-text text-muted">
                                <?php echo e(__( 'messages.tooltip_pwd' )); ?>

                            </p>
                        </div>

                        <div class="form-group <?php echo e($errors->has('password') ? '' : ''); ?>">
                            <label><?php echo e(__( 'messages.confirm_password' )); ?></label>
                            <input id="password-confirm" type="password" class="form-control <?php if($errors->has('password')): ?> is-invalid  <?php endif; ?>" autocomplete="new-password" name="password_confirmation" required>
                        </div>

                        <div class="form-group">
                            <input type="submit" class="" value="<?php echo e(__( 'messages.sign_up' )); ?>" />
                            <span class="already-account"> &nbsp; &nbsp;
                                <?php echo e(__( 'messages.already_account' )); ?>

                                <a href="<?php echo e(route( 'login' )); ?>" class="">
                                    <label><?php echo e(__( 'messages.sign_in' )); ?></label>
                                </a>
                            </span>
                        </div>

                    </form>  
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <script type="text/javascript">
        function socialURL( url ) {
            window.location.href=url;
        }
    </script>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>