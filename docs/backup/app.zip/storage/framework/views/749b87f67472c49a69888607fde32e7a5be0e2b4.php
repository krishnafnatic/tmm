<?php if( isset( $recommended_videos ) && count( $recommended_videos) > 0 ): ?>
  <section id="trending-videos">
   	<h2 class="bd-tranding no-bd-lft">
      <?php if( isset( $heading ) && !empty( $heading ) ): ?>
        <?php echo e($heading); ?>

      <?php else: ?>
        <?php echo e(__( 'messages.recommended_videos' )); ?>

      <?php endif; ?>
    </h2>  
  	<div class="slider responsive">
      <?php $__currentLoopData = $recommended_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
          <a href="<?php echo e(url('video/'.$next['slug'])); ?>">
            <img class="card-img-top" src="<?php echo e($next['images']['thumbnail']['src']); ?>" alt="<?php echo e($next['name']); ?>" title="<?php echo e($next['name']); ?>" />
          </a>
          <div class="card-body">
            <h6 class="card-title">
              <a href="<?php echo e(url('video/'.$next['slug'])); ?>">
                <?php echo e($next['name']); ?>

              </a>
            </h6>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
<?php endif; ?>