<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php if(isset($id)): ?>
          <i class="fa fa-edit"></i>
          <?php echo e(__( 'messages.edit' )); ?>

        <?php else: ?>
          <i class="fa fa-plus"></i>
          <?php echo e(__( 'messages.add' )); ?>

        <?php endif; ?>
        <small><?php echo e(__( 'messages.menu' )); ?></small>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/menu/")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>
          <?php echo e(__( 'messages.back' )); ?>

        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.menu')); ?>">
            <?php echo e(__( 'messages.menu' )); ?>

          </a>
        </li>
        <li class="active">
          <?php if(isset($id)): ?>
            <?php echo e(__( 'messages.edit' )); ?>

          <?php else: ?>
            <?php echo e(__( 'messages.add' )); ?>

          <?php endif; ?>
          <?php echo e(__( 'messages.menu' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-9 col-md-offset-1">
          <!-- general form elements -->
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box box-primary">
            <form class="form" role="form" method="POST" <?php if(isset($id)): ?> action="<?php echo e(url("admin/menu/$id/edit")); ?>" <?php else: ?> action="<?php echo e(route('admin.menu.create.submit')); ?>" <?php endif; ?>>
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                  <label for="name"><?php echo e(__( 'messages.name' )); ?></label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="<?php echo e(__( 'messages.enter_name' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>" <?php endif; ?> maxlength="50" required autofocus autocomplete="off" />
                  <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div> 
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><?php echo e(__( 'messages.submit' )); ?></button>
              </div>
            </form>
          </div> 
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.form_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>