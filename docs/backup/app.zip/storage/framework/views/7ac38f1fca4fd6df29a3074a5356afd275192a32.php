<!DOCTYPE html>
<html>
    <head>
        <title>Contac us Email</title>
    </head>
    
    <body>
        <h2><?php echo e($name); ?> has contacted from contact us form. Below are the details</h2>
        Name: <?php echo e($name); ?>

        <br/>
		E-mail: <?php echo e($email); ?>

		<br/>
		Message: <?php echo e($message); ?>

    </body>

</html>