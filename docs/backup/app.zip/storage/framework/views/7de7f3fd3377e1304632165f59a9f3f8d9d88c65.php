<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0 profile-update-container">
    <div class="container">
        <div class="alert alert-dismissable" id="profile_msg" style="display: none;"></div>
        <div class="row">
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-3 text-center">  
                        <!-- <div id="proife_picture"></div> -->
                        <div class="col-sm-12 text-center user-initials-2" style="padding: 0;" id="upload-demo" onclick="uploadImage();">
                            <?php echo e(substr( Auth::user()->name, 0, 1)); ?>

                            <!-- <img class="user-profile-pic" src="" title="<?php echo e(Auth::user()->name); ?>" alt="<?php echo e(Auth::user()->name); ?>" /> -->
                        </div>

                        <!-- <div class="col-sm-12 " style="padding:5%;"> 
                            <input type="file" id="image" style="display: none;" />
                            <button class="btn btn-sm btn-primary btn-block upload-image" style="margin-top:2%;" disabled>
                                <?php echo e(__( 'messages.upload_image' )); ?>

                            </button>
                        </div> -->
                    </div>
                    <div class="col-sm-8">
                        <h2><?php echo e(Auth::user()->name); ?></h2>
                        <input type="text" id="designation" class="float-left col-sm-12"  disabled style="display: none;" name="designation" value="<?php echo e($user_profile['designation']); ?>" />
                        <h4 id="content_designation"><?php echo e($user_profile['designation']); ?></h4>
                        <button class="btn btn-sm btn-primary text-right" id="edit_designation" onclick="UpdateUserProfileButton( 'designation', '<?php echo e(route("update.profile")); ?>'  )" style="position: relative;">
                            <?php echo e(__( 'messages.edit_designation' )); ?>

                        </button><br><br>
                        <ul class="user-profile-social-ico">
                            <li> 
                                <a href="<?php echo e($user_profile['social']['facebook']); ?>" target="_tab">
                                    <i class="fab fa-facebook fa-2x"></i> 
                                </a> 
                            </li>

                            <li>
                                <a href="<?php echo e($user_profile['social']['linkedin']); ?>" target="_tab">
                                    <i class="fab fa-linkedin fa-2x"></i>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo e($user_profile['social']['google']); ?>" target="_tab">
                                    <i class="fab fa-google fa-2x"></i>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo e($user_profile['social']['twitter']); ?>" target="_tab">
                                    <i class="fab fa-twitter-square fa-2x"></i>
                                </a>
                            </li>
                        </ul>
                        <h6><?php echo e(__( 'messages.interests' )); ?></h6>
                        <div class="user-interested pl-0">
                            <div class="" data-toggle="buttons">
                                <?php if( $user_profile['tags'] ): ?>
                                    <?php $__currentLoopData = $user_profile['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( in_array( $tag->id, $user_profile['user_tag'] ) ): ?>
                                            <label class="btn btn-default active" for="tag">
                                                <input id="tag_<?php echo e($tag->id); ?>" autocomplete="off" value="<?php echo e($tag->id); ?>" name="tag[<?php echo e($tag->id); ?>]" autocomplete="off" value="<?php echo e($tag->id); ?>" name="tag[<?php echo e($tag->id); ?>]" checked type="checkbox" disabled />
                                                <?php echo e($tag->tag); ?>

                                            </label>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>
            <div class="col-sm-1">
                <span class="profile-seperator"> </span> 
            </div>  
            <div class="col-sm-5">
                <div id="div_biography">  
                    <textarea name="biography" id="biography" class="type-main-comment float-left m-0" disabled style="display: none;"><?php if( $user_profile['biography'] ): ?><?php echo e($user_profile['biography']); ?><?php else: ?><?php echo e(__( 'messages.add_about' )); ?><?php endif; ?>
                    </textarea><br><br>
                    <p id="content_biography">
                        <?php if( $user_profile['biography'] ): ?>
                            <?php echo e($user_profile['biography']); ?>

                        <?php else: ?>
                            <?php echo e(__( 'messages.add_about' )); ?>

                        <?php endif; ?>
                    </p>
                </div> 
                <button class="btn btn-sm btn-primary float-left btn-biography" id="edit_biography" onclick="UpdateUserProfileButton( 'biography', '<?php echo e(route("update.profile")); ?>'  )">
                    <?php echo e(__( 'messages.edit_biography' )); ?>

                </button>
            </div>
        </div> 
        <?php if( isset( $recommended_videos ) && count( $recommended_videos) > 0 ): ?>
            <?php echo $__env->make('frontend.account.recommended_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </div> 
</div>
<script type="text/javascript">
    var loader = "<?php echo e(asset( 'frontend/images/loader.png' )); ?>",
        edit_biography = "<?php echo e(__( 'messages.edit_biography' )); ?>",
        edit_designation = "<?php echo e(__( 'messages.edit_designation' )); ?>",
        profile_image_upload = "<?php echo e(__( 'messages.profile_image_upload' )); ?>",
        save_biography = "<?php echo e(__( 'messages.save_biography' )); ?>",
        save_designation = "<?php echo e(__( 'messages.save_designation' )); ?>",
        route_profile = "<?php echo e(route('update.profile')); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>