<div class="dropdown-menu" aria-labelledby="navbarDropdown">
	<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <a class="dropdown-item" href="<?php echo e($child->slug); ?>"><?php echo e($child->title); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
