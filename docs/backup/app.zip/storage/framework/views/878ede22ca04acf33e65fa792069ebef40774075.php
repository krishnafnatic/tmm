<?php if(isset($success) || Session::has('success') ): ?>
	<div class="alert alert-success alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<strong><?php echo e(__( 'messages.success' )); ?></strong> <?php echo e(isset($success) ? $info : Session::get('success')); ?>

	</div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong><?php echo e(__( 'messages.warning' )); ?></strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong><?php echo e(__( 'messages.info' )); ?></strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('status')): ?>
<div class="alert alert-success alert-dismissable">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
    	<?php echo e(__( 'messages.error_msg' )); ?>

    	<button type="button" class="close" data-dismiss="alert">×</button>
     
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul> 
    </div>
<?php endif; ?>