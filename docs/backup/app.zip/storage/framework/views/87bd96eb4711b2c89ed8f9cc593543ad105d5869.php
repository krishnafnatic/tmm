<section id="trending-videos">
 	<h2 class="bd-tranding no-bd-lft">
    <?php echo e(__( 'messages.watch_next' )); ?>

  </h2>  
	<div class="slider responsive">
    <?php $__currentLoopData = $watch_next; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <a href="<?php echo e(url($type.'/'.$next['slug'])); ?>">
          <img class="card-img-top" src="<?php echo e($next['images']['thumbnail']['src']); ?>" alt="<?php echo e($next['name']); ?>" title="<?php echo e($next['name']); ?>" />
        </a>
        <div class="card-body">
          <h6 class="card-title">
            <a href="<?php echo e(url($type.'/'.$next['slug'])); ?>">
              <?php echo e($next['name']); ?>

            </a>
          </h6>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>