	

	<?php $__env->startSection('content'); ?>
		<div class="container my-list">
			<section id="my-list">
               	<h2 class="bd-tranding no-bd-lft"><?php echo e(__( 'messages.my_list' )); ?></h2>
               	<div class="row card-deck">
	               	<?php if( isset( $wishlist ) && count( $wishlist) > 0 ): ?>
	               		<?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			               	<div class="card col-sm-3">
			                    <a href="<?php echo e(url('video/'.$wish['slug'])); ?>">
			                    	<img class="card-img-top" src="<?php echo e($wish['images']['thumbnail']['src']); ?>" alt="<?php echo e($wish['name']); ?>" title="<?php echo e($wish['name']); ?>" />
			                    </a>
			                    <div class="card-body">
			                    	<a href="<?php echo e(url('video/'.$wish['slug'])); ?>" class="card-title">
			                            <?php echo e($wish['name']); ?>

			                        </a>
			                    </div>
			                </div>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	               	<?php else: ?> 
	               		<p><?php echo e(__( 'messages.wishlist_found' )); ?></p>
	               	<?php endif; ?>
		    	</div>
            </section>
		</div>  	
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>