<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php if(isset($id)): ?>
          <i class="fa fa-edit"></i>
          <?php echo e(__( 'messages.edit' )); ?>

        <?php else: ?>
          <i class="fa fa-plus"></i>
          <?php echo e(__( 'messages.add' )); ?>

        <?php endif; ?>
        <small><?php echo e(__( 'messages.information' )); ?></small>
        <button type="button" class="btn btn-primary text-right" onclick="event.preventDefault();
                                 document.getElementById('information-form').submit();">
          <?php if(isset($id)): ?>
            <i class="fa fa-edit"></i>
            <?php echo e(__( 'messages.edit' )); ?>

          <?php else: ?>
            <i class="fa fa-plus-circle"></i>
            <?php echo e(__( 'messages.add' )); ?>

          <?php endif; ?>
        </button>
        <button type="button" class="btn btn-success btn-add-new" onclick="window.location='<?php echo e(url("admin/information")); ?>'">
          <i class="fa fa-arrow-circle-left"></i>  
          <?php echo e(__( 'messages.back' )); ?> 
        </button>
      </h1>
      <ol class="breadcrumb">
        <li>
          <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> 
            <?php echo e(__( 'messages.dashboard' )); ?>

          </a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.information')); ?>">
            <?php echo e(__( 'messages.information' )); ?>

          </a>
        </li>
        <li class="active">
          <?php if(isset($id)): ?>
            <?php echo e(__( 'messages.edit' )); ?>

          <?php else: ?>
            <?php echo e(__( 'messages.add' )); ?>

          <?php endif; ?>
          <?php echo e(__( 'messages.information' )); ?>

        </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" style="margin: 0 auto; width:80%;">
      <div class="row">
        <!-- left column -->
        <div class="col-md-9 col-md-offset-1">
          <!-- general form elements -->
          <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="box box-primary">
            <div class="row">
              <div class="col-md-12">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                  <ul class="nav nav-tabs">
                    <li class="active"><a href="#general" data-toggle="tab"><?php echo e(__( 'messages.general' )); ?></a></li>
                  </ul>
                  <form class="form" id="information-form" role="form" method="POST" <?php if(isset($id)): ?> action="<?php echo e(url("admin/information/$id/edit")); ?>" <?php else: ?> action="<?php echo e(route('admin.information.create.submit')); ?>" <?php endif; ?>>
                    <?php echo e(csrf_field()); ?>

                    <div class="tab-content">
                      <div class="tab-pane active" id="general">
                        <ul class="nav nav-tabs">
                          <?php if($languages): ?> 
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class=" <?php if($loop->first): ?> active <?php endif; ?> ">
                                <a href="#<?php echo e(strtolower( $lang->name )); ?>" data-toggle="tab"><?php echo e($lang->name); ?></a>
                              </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </ul>
                        <div class="tab-content">
                          <?php if($languages): ?> 
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <input type="hidden" id="language_id" name="information_description[<?php echo e($lang->id); ?>][language_id]" value="<?php echo e($lang->id); ?>" />
                              <div class="tab-pane <?php if($loop->first): ?> active <?php endif; ?>"  id="<?php echo e(strtolower( $lang->name )); ?>">
                                <div class="box-body">
                                  <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.title') ? ' has-error' : ''); ?>">
                                    <label for="title"><?php echo e(__( 'messages.title' )); ?></label>
                                    <input type="text" class="form-control" id="title" name="information_description[<?php echo e($lang->id); ?>][title]" placeholder="<?php echo e(__( 'messages.enter_title' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($info[$lang->id]['title']); ?>" <?php else: ?> value="<?php echo e(old('information_description.'.$lang->id.'.title')); ?>" <?php endif; ?> maxlength="100" required autofocus autocomplete="off">
                                    <?php if($errors->has('information_description.'.$lang->id.'.title')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.title')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div> 

                                  <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.short_description') ? ' has-error' : ''); ?>">
                                    <label for="short_description"><?php echo e(__( 'messages.short_description' )); ?></label>
                                    <input type="text" class="form-control" id="short_description" name="information_description[<?php echo e($lang->id); ?>][short_description]" placeholder="<?php echo e(__( 'messages.enter_short_description' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($info[$lang->id]['short_description']); ?>" <?php else: ?> value="<?php echo e(old('information_description.'.$lang->id.'.short_description')); ?>" <?php endif; ?> maxlength="100" required autofocus autocomplete="off">
                                    <?php if($errors->has('information_description.'.$lang->id.'.short_description')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.short_description')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div>

                                  <div class="form-group">
                                    <label for="description"><?php echo e(__( 'messages.description' )); ?></label>
                                    <textarea id="form_editor_<?php echo e($lang->id); ?>" name="information_description[<?php echo e($lang->id); ?>][description]" rows="10" cols="80">
                                      <?php if(isset($id)): ?> <?php echo e($info[$lang->id]['description']); ?> <?php else: ?> <?php echo e(old('information_description.'.$lang->id.'.description')); ?> <?php endif; ?>
                                    </textarea> 
                                    <?php if($errors->has('description')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('description')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div>
                                  <!-- <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.status') ? ' has-error' : ''); ?>">
                                    <label for="order">Status</label>
                                    <select name="information_description[<?php echo e($lang->id); ?>][status]" id="status" class="form-control">
                                      <option value="1" <?php if(isset($info[$lang->id]['status']) && $info[$lang->id]['status'] == 1): ?> selected="selected" <?php endif; ?>><?php echo e(__( 'messages.active' )); ?></option>
                                      <option value="0" <?php if(isset($info[$lang->id]['status']) && $info[$lang->id]['status'] == 0): ?> selected="selected" <?php endif; ?>><?php echo e(__( 'messages.inactive' )); ?></option>
                                    </select>
                                    <?php if($errors->has('information_description.'.$lang->id.'.status')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.status')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div> -->
                                  <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.meta_title') ? ' has-error' : ''); ?>">
                                    <label for="meta_title"><?php echo e(__( 'messages.meta_title' )); ?></label>
                                    <input type="text" class="form-control" id="meta_title" name="information_description[<?php echo e($lang->id); ?>][meta_title]" placeholder="<?php echo e(__( 'messages.enter_meta_title' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($info[$lang->id]['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('information_description.'.$lang->id.'.meta_title')); ?>" <?php endif; ?> maxlength="100"  autocomplete="off" />
                                    <?php if($errors->has('information_description.'.$lang->id.'.meta_title')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.meta_title')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div>

                                  <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.meta_description') ? ' has-error' : ''); ?>">
                                    <label for="meta_description"><?php echo e(__( 'messages.meta_description' )); ?></label>
                                    <input type="text" class="form-control" id="meta_description" name="information_description[<?php echo e($lang->id); ?>][meta_description]" placeholder="<?php echo e(__( 'messages.enter_meta_desc' )); ?>" <?php if(isset($id)): ?> value="<?php echo e($info[$lang->id]['meta_description']); ?>" <?php else: ?> value="<?php echo e(old('information_description.'.$lang->id.'.meta_description')); ?>" <?php endif; ?> maxlength="155"  autocomplete="off" />
                                    <?php if($errors->has('information_description.'.$lang->id.'.meta_description')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.meta_description')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div>
                                  
                                  <div class="form-group<?php echo e($errors->has('information_description.'.$lang->id.'.meta_keyword') ? ' has-error' : ''); ?>">
                                    <label for="meta_keyword"><?php echo e(__( 'messages.meta_keyword' )); ?></label>
                                    <textarea id="meta_keyword" name="information_description[<?php echo e($lang->id); ?>][meta_keyword]" rows="10" cols="80"><?php if(isset($id)): ?> <?php echo e($info[$lang->id]['meta_keyword']); ?> <?php else: ?> <?php echo e(old('information_description.'.$lang->id.'.meta_keyword')); ?> <?php endif; ?>
                                    </textarea> 
                                    <?php if($errors->has('information_description.'.$lang->id.'.meta_keyword')): ?>
                                      <span class="help-block">
                                          <strong><?php echo e($errors->first('information_description.'.$lang->id.'.meta_keyword')); ?></strong>
                                      </span>
                                    <?php endif; ?>
                                  </div>
                                </div>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </div>
                      </div>  
                      <!-- /.tab-pane -->
                    </div>
                  </form>
                  <!-- /.tab-content -->
                </div>
                <!-- nav-tabs-custom -->
              </div>
              <!-- /.col -->
            </div>
              <!-- /.box-body -->
          </div> 
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.form_editor_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>