    

    <?php $__env->startSection('content'); ?>
        <div class="container signup-body">
            <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row justify-content-md-center">
                <div class="col-sm"></div>

                <div class="col-sm hidden-sm hidden-md">
                    <h3 class="text-center"><?php echo e(__( 'messages.logging_help' )); ?></h3>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>" autocomplete="off">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group <?php echo e($errors->has('email') ? '' : ''); ?>">
                            <label><?php echo e(__( 'messages.email' )); ?></label>
                            <input id="validationCustom03" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" autocomplete="off" required />

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <?php echo e($errors->first('email')); ?>

                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <br>    
                            <button type="submit" class="btn-secondary" value="<?php echo e(__( 'messages.submit' )); ?>" onclick="cancelURL( '<?php echo e(route('login')); ?> ' )">
                                <?php echo e(__( 'messages.cancel' )); ?>

                            </button> &nbsp; &nbsp;
                            <input type="submit" class="" value="<?php echo e(__( 'messages.submit' )); ?>" />
                        </div>
                    </form>  
                </div>

                <div class="col-sm signup-box"> </div>
            </div>
        </div>
        <script type="text/javascript">
            function cancelURL( url ) {
                window.location.href=url;
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>