	


	<?php $__env->startSection('content'); ?>
      	<div class="container-fluid px-0">
            <div class="single-detail-video container" >
				<?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            	<div class="alert alert-dismissible" id="msgDiv" style="display: none;"></div>
               	<div class="card" id="divMainContainer">
	                <div class="card-image">
	                    <!-- <div class="embed-responsive embed-responsive-16by9"> -->
	                      	<!-- <iframe src="//players.brightcove.net/<?php echo e($video_detail['account_id']); ?>/oNgLTdNCH_default/index.html?videoId=<?php echo e($video_detail['video_id']); ?>" 
							allowfullscreen 
							webkitallowfullscreen 
							mozallowfullscreen id="myPlayerID"></iframe> -->
							<div style="position: relative; display: block; max-width: 1090px;">
								<div style="padding-top: 56.25%;">
									<video id="myPlayerID"
									  data-video-id="<?php echo e($video_detail['video_id']); ?>" 
									  data-account="<?php echo e($video_detail['account_id']); ?>" 
									  data-player="oNgLTdNCH" 
									  data-embed="default" 
									  data-application-id 
									  class="video-js" 
									  controls style="position: absolute; top: 0px; right: 0px; bottom: 0px; left: 0px; width: 100%; height: 100%;"></video>
									<script src="//players.brightcove.net/<?php echo e($video_detail['account_id']); ?>/oNgLTdNCH_default/index.min.js"></script>
								</div>
							</div>
	                    <!-- </div> -->
	                </div>

	                <p style="display: none;">video start cookie value = <span id="cookieDisplay1"></span></p>
					<p style="display: none;">current cookie value = <span id="cookieDisplay2"></span></p>

                	<div class="row single-video-title-padding">
                      	<div class="card-content col-sm-9">       
                          	<h1 class="card-title">
                          		<?php echo e($video_detail['name']); ?>

                          	</h1>
                          	<p><?php echo e($video_detail['description']); ?></p>
                      	</div>

                      	<?php echo $__env->make('frontend.video_details.tag' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                	</div>
            	</div>
            </div>
      	</div>  
       	<!-- Single detail-video Start Here -->
       	<div class="container">
          	<div class="speaker-comment-box card">
             	<ul class="nav nav-pills mb-3 tabbing" id="pills-tab" role="tablist">
	                <li class="nav-item">
	                  	<a class="nav-link active" id="speaker-tab" data-toggle="tab" href="#tab-speaker" role="tab" aria-controls="tab-speaker" aria-selected="true">
	                  		<?php echo e(__( 'messages.speakers')); ?>

	                  	</a>
	                </li>
	                <li class="nav-item">
	                  	<a class="nav-link" id="comment-tab" data-toggle="tab" href="#comments" role="tab" aria-controls="comment" aria-selected="false">Comments</a>
	                </li>
              	</ul>
              	<div class="tab-content" id="pills-tabContent">
                	<div class="tab-pane fade show active" id="tab-speaker" role="tabpanel" aria-labelledby="speaker-tab">
                    	<?php echo $__env->make('frontend.video_details.speaker', [ 'speakers' => $speakers], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                	</div>
	                <div class="tab-pane fade" id="comments" role="tabpanel" aria-labelledby="comment-tab">
	                	<?php if(auth()->guard()->guest()): ?>
		                  	<div class="not-login">
			                    <h5><?php echo e(__( 'messages.join_conversation' )); ?></h5>
			                    <a href="" class="btn" data-toggle="modal" data-target="#user-login">
			                    	<?php echo e(__( 'messages.login_comment' )); ?>

			                    </a>
		                  	</div>
		                <?php else: ?>
		                	<!-- Comments box start-->
					        <div class="alert alert-dismissable" id="msgComment" style="display: none;">
					        </div>
		                    <div class="row comments-box">
		                        <textarea class="type-main-comment" placeholder="<?php echo e(__( 'messages.add_comment' )); ?>" onclick="event.preventDefault();enableComment( 'main_comment' );" maxlength="<?php echo e(env( 'total_characters' )); ?>" id="comment"></textarea>
		                    </div>
		                    <div class="word-counter">
								<label id="count-label"><?php echo e(env( 'total_characters' )); ?></label> 
								<?php echo e(__( 'messages.characters_remaining' )); ?> 
								
							</div>
		                    <div class="float-right  comment-action-group" style="display: none;" id="main_comment">
                                <input type="button" onclick="event.preventDefault();cancelComment( 'main_comment', 'comment', 'count-label' );" class="btn cancel-comment btn-secondary btn-sm " value="Cancel" />
                                <input type="submit" disabled class="btn btn-secondary btn-sm" value="Comment" id="submitComment" />
                          </div>
		                <?php endif; ?>

	                    <div class="row" id="commentListing"></div>
	                </div>
              	</div>
          	</div>
          	<!-- Remaning Ad and Page with Videos Start-->
          	<div class="tmm-image-ad d-none" id="home-ad-1">
             	<a href="https://www.semiqolon.com"> <img src="<?php echo e(asset( 'frontend/images/tmm-ad.jpg' )); ?>"  class="img-fluid"> </a>
          	</div>  
          	<?php if( isset( $watch_next ) && count( $watch_next) > 0 ): ?>
          		<?php echo $__env->make('frontend.video_details.watch_next', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          	<?php endif; ?>

          	<?php if( isset( $playlist_watch_next ) && count( $playlist_watch_next) > 0 ): ?>
          		<?php $__currentLoopData = $playlist_watch_next; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          			<?php echo $__env->make('frontend.video_details.playlist_video', [ 'playlist_videos' => $home ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          	<?php endif; ?>

          	<?php if(Auth::check()): ?>
        		<?php echo $__env->make('frontend.video_details.my_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	<?php endif; ?>
	    </div>
        <?php if(auth()->guard()->guest()): ?>
       		<input type="hidden" value="0" id="logged_user_id" />
       	<?php else: ?>
       		<input type="hidden" value="<?php echo e(Auth::user()->id); ?>" id="logged_user_id" />
       	<?php endif; ?>
       <?php echo $__env->make('frontend.video_details.login_popup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

       <script type="text/javascript">
			var account_id 	= 	"<?php echo e($video_detail['account_id']); ?>",
				video_id 	= 	"<?php echo e($video_detail['video_id']); ?>",
				analyticsURL =  "<?php echo e(url( 'bc/analytics' )); ?>",
				loginURL 	 =  "<?php echo e(url( '/loginAjax' )); ?>",
				commentListURL 	 =  "<?php echo e(url( '/commentList' )); ?>",
				commentURL 	 =  "<?php echo e(url( '/comment' )); ?>",
				wishListURL   =  "<?php echo e(url( '/wishList' )); ?>",
			    msg       =   "<?php echo e(__( 'messages.error_ajax' )); ?>",
			    requiredEmail  = "<?php echo e(__( 'validation.required', ['attribute' => 'Email' ] )); ?>",
			    requiredPWD  = "<?php echo e(__( 'validation.required', ['attribute' => 'Password' ] )); ?>",
			    emailValid  = "<?php echo e(__( 'validation.email', ['attribute' => 'Email' ] )); ?>",
			    pwdValid	= "<?php echo e(__( 'messages.pwdVaild', ['attribute' => 'Password'])); ?>",
			    limitCharacters = "<?php echo e(env( 'total_characters' )); ?>",
			    charactersRemaining = "<?php echo e(__( 'messages.characters_remaining' )); ?>",
			    checkIsWhishListURL = "<?php echo e(url( '/checkIsWhishList' )); ?>";
		</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.video_detail_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>