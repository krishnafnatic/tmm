<?php if( isset( $popular_videos ) && count( $popular_videos) > 0 ): ?>
    <section id="popular-videos">
        <h2 class="bd-magenta">
            <?php if( isset( $heading ) && !empty( $heading ) ): ?>
                <?php echo e($heading); ?>

            <?php else: ?>
                <?php echo e(__( 'messages.recommended_videos' )); ?>

            <?php endif; ?>
        </h2>  
        <div class="slider responsive">
            <?php $__currentLoopData = $popular_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(url('popular/'.$popular['slug'])); ?>">
                        <img class="card-img-top" src="<?php echo e($popular['images']['thumbnail']['src']); ?>" alt="<?php echo e($popular['name']); ?>" title="<?php echo e($popular['name']); ?>" />
                    </a>
                    <div class="card-body">
                        <h6 class="card-title">
                            <a href="<?php echo e(url('popular/'.$popular['slug'])); ?>">
                                <?php echo e($popular['name']); ?>

                            </a>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>