<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<?php echo $__env->make('frontend.elements.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<?php echo $__env->make('frontend.elements.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main role="main">
		<?php echo $__env->make('frontend.home_templates.banner_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="container">
			<?php echo $__env->make('frontend.home_templates.advertisement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.trending_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.advertisement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.popular_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  	
			<?php echo $__env->make('frontend.home_templates.advertisement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.playlist1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 	
			<?php echo $__env->make('frontend.home_templates.advertisement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.playlist2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('frontend.home_templates.advertisement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</main>	  	
	<?php echo $__env->make('frontend.elements.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script src="<?php echo e(asset( 'frontend/js/multi-carousel2.js' )); ?>""></script>
</body>
</html>