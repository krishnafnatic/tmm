	

	<?php $__env->startSection('content'); ?>
		<div class="container">
			<br /><br /> <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="row contact-us">
			 	<div class="col-sm-5">
		 	  		<h1> 
		 	  			<span> India’s premier </span> 
		 	  			<br> money, investment and personal finance offering.
		 	  		</h1>
			 	</div>
		 	  	<div class="col-sm-2">
		 	  		<div class="vl"> </div>
		 	  	</div>
		 	  	<div class="col-sm-5">
		 	  		<h5> Email us </h5>	
		 	  		<a href="mailto:themoneymile2@gmail.com" target="_top">themoneymile2@gmail.com</a>
		 	  		<br> <hr> <br>
		 	  		<h5>Send us a message</h5>
		 	  		<form class="col-12 contact-us-from pl-0" action="<?php echo e(route( 'contact_us' )); ?>" method="get" role="contact">
		 	  			<div class="form-group<?php echo e($errors->has('name') ? '' : ''); ?>">
			 	  			<label>Name</label>
			 	  			<input type="text" name="name" id="name" class="form-control" value="<?php echo e(old( 'name' )); ?>" placeholder="<?php echo e(__('messages.enter_name')); ?>" autocomplete="off" required>
			 	  			<?php if($errors->has('name')): ?>
			                    <span class="text-danger">
			                        <?php echo e($errors->first('name')); ?>

			                    </span>
		                  	<?php endif; ?>
		                </div>

		                <div class="form-group <?php echo e($errors->has('email') ? '' : ''); ?>">
			 	  			<label>Email</label>
			 	  			<input type="text" name="email" id="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e(old( 'email' )); ?>" placeholder="<?php echo e(__('messages.enter_email')); ?>" autocomplete="off" required>
			 	  			<?php if($errors->has('email')): ?>
			                    <span class="text-danger">
			                        <?php echo e($errors->first('email')); ?>

			                    </span>
		                  	<?php endif; ?>
		                </div>

		                <div class="form-group<?php echo e($errors->has('message') ? '' : ''); ?>">
			 	  			<label>Message</label>
			 	  			<textarea class="col" name="message" id="message"  value="<?php echo e(old( 'message' )); ?>" placeholder="<?php echo e(__('messages.enter_message')); ?>"   required></textarea>
			 	  			<input type="submit" name="" value="<?php echo e(__('messages.send')); ?>">
			 	  			<?php if($errors->has('message')): ?>
			                    <span class="text-danger">
			                        <?php echo e($errors->first('message')); ?>

			                    </span>
		                  	<?php endif; ?>
			 	  		</div>
		 	  		</form>
		 	 	</div>
			</div>	
		</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>