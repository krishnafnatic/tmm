<div class="pull-right hidden-xs">
  	<b><?php echo e(__( 'messages.version' )); ?></b> 2.4.0
</div>
<strong>
	<?php echo e(__( 'messages.copyright' )); ?> &copy; <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> 
	<a href="<?php echo e(url('/')); ?>" target="_tab"><?php echo e(config('app.name', 'Laravel')); ?></a>. 
</strong> 
<?php echo e(__( 'messages.all_right_reserved' )); ?>