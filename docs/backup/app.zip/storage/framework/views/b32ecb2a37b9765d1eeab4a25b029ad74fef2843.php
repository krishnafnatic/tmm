<section id="open-house-videos">
    <h2 class="bd-cyan"><?php echo e($video_title); ?></h2>  
    <div class="slider responsive">
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="<?php echo e(url('video/'.$video['slug'])); ?>">
                    <img class="card-img-top" src="<?php echo e($video['images']['thumbnail']['src']); ?>" alt="<?php echo e($video['name']); ?>" title="<?php echo e($video['name']); ?>" />
                </a>
                <div class="card-body">
                    <h6 class="card-title">
                        <a href="<?php echo e(url('video/'.$video['slug'])); ?>">
                            <?php echo e($video['name']); ?>

                        </a>
                    </h6>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>