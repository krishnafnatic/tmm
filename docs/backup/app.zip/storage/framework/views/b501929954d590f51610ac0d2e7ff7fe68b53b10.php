<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo e(__( 'messages.dashboard' )); ?>

        <small><?php echo e(__( 'messages.control_panel' )); ?></small>
      </h1>
      <ol class="breadcrumb">
        <li class="active">
          <i class="fa fa-dashboard"></i>&nbsp;&nbsp;
          <?php echo e(__( 'messages.dashboard' )); ?>

        </li>
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <?php echo $__env->make('backend.elements.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-video-camera"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><?php echo e(__( 'messages.videos' )); ?></span>
              <span class="info-box-number"><?php echo e(App\Models\Video::all()->count()); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-th-list"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><?php echo e(__( 'messages.playlists' )); ?></span>
              <span class="info-box-number"><?php echo e(App\Models\Playlist::all()->count()); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-tags"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><?php echo e(__( 'messages.tags' )); ?></span>
              <span class="info-box-number"><?php echo e(App\Models\Tag::all()->count()); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-play-circle"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><?php echo e(__( 'messages.players' )); ?></span>
              <span class="info-box-number"><?php echo e(App\Models\Player::all()->count()); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>

      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">  
              <i class="fa fa-video-camera"></i>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__( 'messages.add_update_videos' )); ?>

            </div> 
            <a href="<?php echo e(route( 'admin.video' )); ?>" class="small-box-footer">
              <?php echo e(__( 'messages.manually' )); ?> <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div> 
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <i class="fa fa-th-list"></i>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__( 'messages.add_update_playlists' )); ?>

            </div>
            <a href="<?php echo e(route( 'admin.playlist' )); ?>" class="small-box-footer">
              <?php echo e(__( 'messages.manually' )); ?> <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__( 'messages.add_update_tags' )); ?>

            </div>
            <a href="<?php echo e(route( 'admin.tag' )); ?>" class="small-box-footer">
              <?php echo e(__( 'messages.manually' )); ?> <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          
          <div class="small-box bg-red">
            <div class="inner">
              <i class="fa fa-play-circle"></i>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(__( 'messages.add_update_player' )); ?>

            </div>
            <a href="<?php echo e(route('admin.player')); ?>" class="small-box-footer">
              <?php echo e(__( 'messages.manually' )); ?> <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
      </div>

      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo e(App\Models\User::where('role_id', 2)->count()); ?></h3>

              <p><?php echo e(__( 'messages.user_registrations' )); ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('admin.user')); ?>" class="small-box-footer">
              <?php echo e(__( 'messages.more_info' )); ?> <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div> 
      </div>
      <!-- /.row --> 

    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>