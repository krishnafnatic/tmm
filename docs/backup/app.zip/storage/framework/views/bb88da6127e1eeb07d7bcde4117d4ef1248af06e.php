<div class="col-sm-3 views-tags" id="view-tags">
    <a class="social_media" id="social_media" title="Social Share" onclick="document.getElementById('social_share_custom').style.display='block';"> 
        <img src="<?php echo e(asset( 'frontend/images/social/share.png' )); ?>" alt="Social Share" title="Social Share" />
    </a>
    <a class="add-to-wishlist" id="add_to_list" title="Add to list" onclick="user_list('add')"> 
        <img src="<?php echo e(asset( 'frontend/images/social/heart_normal.png' )); ?>" alt="Add to list" title="Add to list" />
    </a>
	<div class="video-views" id="view-video">
    	<div class="viewcount" id="viewcount"></div>
        <div class="viewlabel"><?php echo e(__( 'messages.views' )); ?></div>
	</div>
	<div class="video-related-tags">
    	<h6><?php echo e(__( 'messages.realated_tags' )); ?></h6>
    	<?php if(count($video_detail['tags']) > 0): ?>
    		<?php $__currentLoopData = $video_detail['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    			<?php if($loop->last): ?>
    				<a href="<?php echo e(url( '/tag/'. $tag)); ?>"><?php echo e($tag); ?></a> 
    			<?php else: ?> 
    				<a href="<?php echo e(url( '/tag/'. $tag)); ?>"><?php echo e($tag); ?></a>,
    			<?php endif; ?> 
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	<?php endif; ?>
	</div>
</div>