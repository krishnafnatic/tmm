<header class="main-header">
  <!-- Logo -->
  <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini">T<b>M</b>M</span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><b><?php echo e(config('app.name', 'Laravel')); ?></b></span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
      <span class="sr-only"><?php echo e(__( 'messages.toggle_navigation' )); ?></span>
    </a>

    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">
        <!-- User Account: style can be found in dropdown.less -->
          
        <?php if(auth()->guard("admin")->check()): ?>
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <img src="<?php echo e(asset('backend/dist/img/avatar5.png')); ?>" class="user-image" alt="<?php echo e(__( 'messages.user_image' )); ?>">
                <span class="hidden-xs"><?php echo e(Auth::guard('admin')->user()->name); ?></span>
              </a>
              <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">
                  <img src="<?php echo e(asset('backend/dist/img/avatar5.png')); ?>" class="img-circle" alt="<?php echo e(__( 'messages.user_image' )); ?>">

                  <p>
                    <?php echo e(Auth::guard('admin')->user()->name); ?>

                    <small><?php echo e(__( 'messages.member_since' )); ?>  <?php echo e(\Carbon\Carbon::parse(Auth::guard('admin')->user()->created_at)->format('M, d Y')); ?></small>
                  </p>
                </li>
                <li class="user-footer">  
                  <div class="pull-right">
                    <a href="#" class="btn btn-default btn-flat"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();"><?php echo e(__( 'messages.sign_out' )); ?></a>
                    <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                  </div>
                </li>
              </ul>
            </li> 
        <?php endif; ?>
      </ul>
    </div>
  </nav>
</header>