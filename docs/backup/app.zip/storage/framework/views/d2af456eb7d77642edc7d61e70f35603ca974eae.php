 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="user-account-holder card">
             <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">  
                <div class="col-sm-3 tmm-account-tab">
                    <div class="nav flex-column nav-pills account-tabs" id="v-pills-tab" role="account" aria-orientation="vertical">
                        <a class="nav-link" href="<?php echo e(route( 'profile' )); ?>" role="profile">
                            <?php echo e(__( 'messages.profile' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'change-password' )); ?>" role="change-password">
                            <?php echo e(__( 'messages.password' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'user-notification' )); ?>" role="notification">
                            <?php echo e(__( 'messages.notification' )); ?>

                        </a>
                        <a class="nav-link active" href="<?php echo e(route( 'profile-deactivate' )); ?>" role="deactivate_account">
                            <?php echo e(__( 'messages.deactivate_account' )); ?>

                        </a>
                    </div>
                </div>  
                
                <div class="col-sm-9">
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('profile-deactivate')); ?>" autocomplete="on" role="deactivate_account">
                                <?php echo e(csrf_field()); ?>  
                                <h3> <?php echo e(__( 'messages.deactivate_account' )); ?> </h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <h6><?php echo e(__( 'messages.reason_account_deactivate' )); ?></h6> 
                                        <form class="manage-password">
                                            <div class="form-group<?php echo e($errors->has('reason_deactivate') ? ' was-validated' : ''); ?>">
                                                <select class="form-control col-sm-12" name="reason_deactivate">
                                                    <option value="0">
                                                        <?php echo e(__( 'messages.select_reason' )); ?>

                                                    </option>
                                                    <?php if($reason): ?>
                                                        <?php $__currentLoopData = $reason; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($r->id); ?>" <?php echo e($r->id == $deactivate_reason ? 'selected' : ''); ?> > 
                                                                <?php echo e($r->name); ?> 
                                                                </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('reason_deactivate')): ?>
                                                    <div class="text-danger">
                                                        <?php echo e($errors->first('reason_deactivate')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <br>
                                            <div class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?>">
                                                <label class="col-sm-12 pl-0 clearfix"> 
                                                    <?php echo e(__( 'messages.password' )); ?>

                                                </label> <br>
                                                <input id="current-password" type="password" class="col-sm-12 clearfix form-control" name="current-password" required autocomplete="off" />
                                                <div class="col-sm-12 user-social-inputs-action pl-0">
                                                    <button type="button" class="btn btn-secondary" onclick="event.preventDefault();window.history.back();">
                                                        <?php echo e(__( 'messages.cancel' )); ?>

                                                    </button>&nbsp;&nbsp;                                         
                                                    <button type="submit" class="btn btn-primary">
                                                         <?php echo e(__( 'messages.deactivate' )); ?>

                                                    </button>
                                                </div>    
                                            </div>    
                                        </form>
                                    </div>
                                    <div class="col-sm-6 text-right">
                                        <img src="<?php echo e(asset( 'frontend/images/delete-account.png' )); ?>" class="lock">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>