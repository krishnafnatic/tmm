<?php if( isset( $playlist2 ) && count( $playlist2) > 0 ): ?>
    <section id="open-house-videos">
        <h2 class="bd-cyan"><?php echo e($playlist2['p2_name']); ?></h2>  
        <div class="slider responsive">
            <?php $__currentLoopData = $playlist2['p2_videos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(url('video/'.$video['v2_slug'])); ?>" title="<?php echo e($video['v2_name']); ?>">
                        <img class="card-img-top" src="<?php echo e($video['v2_images']['poster']['src']); ?>" alt="<?php echo e($video['v2_name']); ?>" title="<?php echo e($video['v2_name']); ?>" />
                    </a>
                    <div class="card-body">
                        <h6 class="card-title">
                            <a href="<?php echo e(url('video/'.$video['v2_slug'])); ?>" title="<?php echo e($video['v2_name']); ?>">
                                <?php echo e($video['v2_name']); ?>

                            </a>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>