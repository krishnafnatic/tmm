    

    <?php $__env->startSection('content'); ?>
    	<div class="container signup-body">
    		<?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	<div class="row justify-content-md-center">
	            <div class="col-sm">
	                <div class="col-sm social-btn signin-social-btn-mr">
		                <a href="#" class="btn btn-primary col fb-login" onclick=" socialURL( '<?php echo e(route('auth.facebook')); ?>' )">
		                 	<i class="fab fa-facebook-square fa-2x"></i>
		                 	<div><?php echo e(__( 'messages.login_with_fb' )); ?></div>
		                </a>
		                 <a href="#" class="btn btn-primary col gmail-login" onclick=" socialURL( '<?php echo e(route('auth.google')); ?> ' )">
		                 	<i class="fab fa-google fa-2x"></i>
		                 	<div><?php echo e(__( 'messages.login_with_gg' )); ?></div>
		                </a>
		                 <a href="#" class="btn btn-primary col linkedin-login" onclick=" socialURL( '<?php echo e(route('auth.linkedin')); ?>' )">
		                 	<i class="fab fa-linkedin fa-2x"></i>
		                 	<div><?php echo e(__( 'messages.login_with_li' )); ?></div>
		                </a>
	                </div>
	            </div>

            	<div class="col-sm hidden-sm hidden-md">
            		<div class="vl"> 
            			<span class="or"> <?php echo e(__( 'messages.or' )); ?> </span> 
            		</div> 
            	</div>

	            <div class="col-sm signup-box">
                  	<h3><?php echo e(__( 'messages.sign_in' )); ?></h3>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>" autocomplete="off">
                    	<?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('email') ? '' : ''); ?>">
                            <label><?php echo e(__( 'messages.email' )); ?></label>
                            <input id="email" type="email" class="form-control <?php if($errors->has('email')): ?> is-invalid  <?php endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="off" />

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <?php echo e($errors->first('email')); ?>

                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' was-validated' : ''); ?>">
                            <label><?php echo e(__( 'messages.password' )); ?></label>
                            <input id="password" type="password" class="form-control <?php if($errors->has('password')): ?> is-invalid  <?php endif; ?>" name="password" required autocomplete="current-password" />
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>
                            <br />
                            <label class="remember-me">
                               <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>><?php echo e(__( 'messages.remember_me' )); ?>

                            </label>
                            <label class="remember-me">
                                <a href="<?php echo e(route( 'password.request' )); ?>">
                                    <?php echo e(__( 'messages.forgot_password' )); ?>

                                </a>
                            </label>
                        </div>
                        <div class="form-group">
                            <input type="submit" class="" value="<?php echo e(__( 'messages.sign_in' )); ?>" />
                            
                            <span class="already-account"> &nbsp; &nbsp;
                                <?php echo e(__( 'messages.account_yet' )); ?>

                                <a href="<?php echo e(route( 'register' )); ?>" class="">
                                    <?php echo e(__( 'messages.sign_up' )); ?>

                                </a>
                            </span>
                        </div>
                    </form>  
	            </div>
        	</div>
      	</div>
        <script type="text/javascript">
            function socialURL( url ) {
                window.location.href=url;
            }
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>