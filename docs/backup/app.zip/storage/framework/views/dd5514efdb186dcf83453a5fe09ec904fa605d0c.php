<?php if( isset( $speakers ) && count( $speakers ) > 0 ): ?>
	<ul class="video-speaker-profile">
		<?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	<li> 
		        <a href="<?php echo e(url( 'speaker/'.$speaker['slug'] )); ?>" class="profile-pic float-left">
		        	<img src="<?php echo e(asset( $speaker['avatar'] )); ?>" alt="<?php echo e($speaker['name']); ?> " title="<?php echo e($speaker['name']); ?> " />
		        </a>
		        <a href="<?php echo e(url( 'speaker/'.$speaker['slug'] )); ?>" class="title" title="<?php echo e($speaker['name']); ?> ">
		        	<?php echo e($speaker['name']); ?> 
		        </a>
		        <div class="designation">
 		        	<?php echo e($speaker['designation']); ?>

		        </div>
		        <p>
		        	<?php echo e($speaker['short_description']); ?>

		        </p>
		    </li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
<?php else: ?>
	<ul class="video-speaker-profile">
		<p><?php echo e(__( 'messages.speaker_found' )); ?></p>
	</ul>
<?php endif; ?>