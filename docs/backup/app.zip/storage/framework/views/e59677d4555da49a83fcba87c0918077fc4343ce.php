	

	<?php $__env->startSection('content'); ?>
		<div class="container-fluid px-0 profile-update-container">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-3 text-center">
	                            <div class="user-initials-2">
	                            	<?php
                            			$name = $speakers_detail['name'];
                            			$designation = $speakers_detail['designation'];
                            			$short_description = $speakers_detail['short_description'];
                            		?>
	                            	<?php if( !empty( $speakers_detail['avatar'] ) ): ?>
	                                	<img src="<?php echo e(asset( '/'.$speakers_detail['avatar'])); ?>" width="100%" height="100%" title="<?php echo e($name); ?>" alt="<?php echo e($name); ?>" style="    border-radius: 100px;" />
	                                <?php endif; ?>
	                            </div>
                            	<!-- <a href="" class="edit-profile-2">Edit Profile</a> -->
                            </div>
                            <div class="col-sm-8">
                              	<h2><?php echo e($name); ?></h2>
                              	<h4><?php echo e($designation); ?></h4>
	                            <ul class="user-profile-social-ico">
                                    <?php if( isset( $social['facebook'] ) && !empty( $social['facebook'] ) ): ?>
	                                   <li> 
                                            <a href="<?php echo e($social['facebook']); ?>">
                                                <i class="fab fa-facebook fa-2x"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if( isset( $social['linkedin'] ) && !empty( $social['linkedin'] ) ): ?>
                                       <li> 
                                            <a href="<?php echo e($social['linkedin']); ?>">
                                                <i class="fab fa-linkedin fa-2x"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if( isset( $social['google'] ) && !empty( $social['google'] ) ): ?>
                                       <li> 
                                            <a href="<?php echo e($social['google']); ?>">
                                                <i class="fab fa-google fa-2x"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if( isset( $social['twitter'] ) && !empty( $social['twitter'] ) ): ?>
                                       <li> 
                                            <a href="<?php echo e($social['twitter']); ?>">
                                                <i class="fab fa-twitter-square fa-2x"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
	                            </ul>
                            </div>
                        </div>    
                    </div>
                    <div class="col-sm-1">
                        <span class="profile-seperator"> </span> 
                    </div>  
                    <div class="col-sm-5">
                        <p> <?php echo e($short_description); ?> </p> 
                    </div>
                </div>
            </div>  
      	</div>

        <div class="container">  
            <?php echo $__env->make('frontend.speaker.video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>   
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>