<footer class="container-fluid">
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col">
                <ul class="footer-nav">
                    <?php if( isset( $menu_footer ) &&count( $menu_footer ) > 0 ): ?>
                        <?php $__currentLoopData = $menu_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($footer->icon_class); ?> nav-item <?php echo e(Request::is( $footer->slug ) ? 'active' : ''); ?>">
                                <a href="<?php echo e($footer->slug); ?>" target="<?php echo e($footer->target); ?>">
                                    <?php echo e($footer->title); ?>

                                </a> 
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-md-auto footer-subscribe" id="divSubscribeMe">
                <h5><?php echo e(__( 'messages.subscribe_newsletter' )); ?></h5>
                <div class="alert alert-dismissible" id="msgSubscribMe" style="display: none;"></div>
                <div class="form-inline my-2 my-lg-0 ml-auto <?php echo e($errors->has('name') ? ' was-validated' : ''); ?>" role="subscribe">
                    <input type="text" name="subscribe_name" id="subscribe_name" placeholder="<?php echo e(__( 'messages.name' )); ?>" autocomplete="off" required />
                    <input type="email" name="subscribe_email" id="subscribe_email" placeholder="<?php echo e(__( 'messages.email' )); ?>" autocomplete="off" required />
                    <button type="submit" onclick="subscribeMe();" id="subscribeMe"><?php echo e(__( 'messages.subscribe' )); ?></button>
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <h6><?php echo e(__( 'messages.never_span' )); ?></h6> 
                </div>
            </div>
            <div class="col footer-social">
                <h5><?php echo e(__( 'messages.find_on_social' )); ?></h5>
                <ul class="">
                    <li> <a href="" target="_tab"> <i class="fab fa-youtube-square"></i>  </a> </li>
                    <li> <a href="" target="_tab"> <i class="fab fa-facebook-square"></i> </a> </li>
                    <li> <a href="" target="_tab"> <i class="fab fa-linkedin"></i> </a> </li>
                    <li> <a href="" target="_tab"> <i class="fab fa-twitter"></i> </a> </li>
                    <li> <a href="" target="_tab"> <i class="fab fa-google-plus-g"></i> </a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid copyright ">
        <div class="container"> 
            <div class="row">
                <ul class="ft-menu col-4">
                    <?php if( isset( $menu_cms_footer ) && count( $menu_cms_footer ) > 0 ): ?>
                        <?php $__currentLoopData = $menu_cms_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cms_footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($cms_footer->icon_class); ?> <?php echo e(Request::is( $cms_footer->slug ) ? 'active' : ''); ?>">
                                <a href="<?php echo e($cms_footer->slug); ?>" target="<?php echo e($cms_footer->target); ?>">
                                    <?php echo e($cms_footer->title); ?>

                                </a> 
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="col-8 copy-note"> 
                    &copy; Copyright <?php echo e(\Carbon\Carbon::now()->format('Y')); ?>.
                    <?php echo e(__( 'messages.all_right_reserved' )); ?>

                </div>
            </div>
        </div> 
    </div>
    <script type="text/javascript">
        var subscribeMeURL=  "<?php echo e(url( '/subscribe' )); ?>",
            loader    =   "<?php echo e(asset( 'frontend/images/loader.png' )); ?>";
    </script>
</footer>