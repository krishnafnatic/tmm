 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="user-account-holder card">
            <?php echo $__env->make('frontend.elements.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row">  
                <div class="col-sm-3 tmm-account-tab">
                    <div class="nav flex-column nav-pills account-tabs" id="v-pills-tab" role="account" aria-orientation="vertical">
                        <a class="nav-link" href="<?php echo e(route( 'profile' )); ?>" role="profile">
                            <?php echo e(__( 'messages.profile' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'change-password' )); ?>" role="change-password">
                            <?php echo e(__( 'messages.password' )); ?>

                        </a>
                        <a class="nav-link active" href="<?php echo e(route( 'user-notification' )); ?>" role="notification">
                            <?php echo e(__( 'messages.notification' )); ?>

                        </a>
                        <a class="nav-link" href="<?php echo e(route( 'profile-deactivate' )); ?>" role="deactivate_account">
                            <?php echo e(__( 'messages.deactivate_account' )); ?>

                        </a>
                    </div>
                </div>  
                
                <div class="col-sm-9">
                    <div class="tab-content" id="v-pills-tabContent">
                         <div class="tab-pane fade show active" id="notification" role="notification">
                            <form class="form-horizontal" role="notification" method="POST" action="<?php echo e(route('user-notification')); ?>" autocomplete="on" id="needs-validation" novalidate>
                                <?php echo e(csrf_field()); ?> 
                                <h3> <?php echo e(__( 'messages.notification' )); ?> </h3>
                                <h6><?php echo e(__( 'messages.newsletter_notification' )); ?></h6> 
                                <p><?php echo e(__( 'messages.monthly_newsletter' )); ?></p> 
                                <div class="form-group<?php echo e($errors->has('newsletter') ? ' was-validated' : ''); ?>">
                                    <label class="btn btn-default pl-0">
                                        <input id="newsletter" type="radio" class="" value="on" name="newsletter" <?php echo e($n_notify == 'on' ? 'checked' : ''); ?> />
                                        <?php echo e(__( 'messages.on' )); ?>

                                    </label>
                                    <label class="btn btn-default">
                                        <input id="newsletter" type="radio" class="" value="off" name="newsletter" <?php echo e($n_notify == 'off' ? 'checked' : ''); ?> />
                                        <?php echo e(__( 'messages.off' )); ?>

                                    </label> 
                                    <br />
                                     <?php if($errors->has('newsletter')): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('newsletter')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <h6><?php echo e(__( 'messages.video_notification' )); ?></h6> 
                                <p><?php echo e(__( 'messages.monthly_video' )); ?></p>  

                                <div class="form-group<?php echo e($errors->has('video') ? ' was-validated' : ''); ?>">
                                    <label class="btn btn-default pl-0">
                                        <input id="video" type="radio" class="" value="on" name="video" <?php echo e($v_notify == 'on' ? 'checked' : ''); ?> />
                                        <?php echo e(__( 'messages.on' )); ?>

                                    </label>
                                    <label class="btn btn-default">
                                        <input id="video" type="radio" class="" value="off" name="video" <?php echo e($v_notify == 'off' ? 'checked' : ''); ?> />
                                        <?php echo e(__( 'messages.off' )); ?>

                                    </label> 
                                    <br />
                                    <?php if($errors->has('video')): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('video')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-2"> &nbsp;</div>
                                    <div class="col-sm-10 user-social-inputs-action">
                                        <button type="button" class="btn btn-secondary" onclick="event.preventDefault();window.history.back();">
                                            <?php echo e(__( 'messages.cancel' )); ?>

                                        </button>&nbsp;&nbsp;
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__( 'messages.save_changes' )); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>